// js/hud/profile.js — panneau personnage haut-gauche : portrait, niveau,
// PV rouge, XP or, charge d'ultime. Barre de vie avec traînée de dégât
// et flash de soin — tout est relié aux vraies stats de G.player.
import { G, ctx, TAU } from '../state.js';
import { roundRect } from '../utils.js';
import { curWorld } from '../world.js';
import { activeSlot, slotMeta } from '../chars.js';
import { HPAL, metalFrame, medBar, engraved, gem } from './frame.js';
import { modShieldMax } from '../modules.js';

const PW = 330, PH = 132, PX = 14, PY = 10;

// portrait de chevalier procédural (heaume + nasal + panache or)
function drawPortrait(cx, cy, r) {
  ctx.save();
  ctx.translate(cx, cy);
  // fond : disque métal sombre
  const bg = ctx.createRadialGradient(0, -r * 0.3, r * 0.2, 0, 0, r);
  bg.addColorStop(0, '#4a4038'); bg.addColorStop(1, '#1c1712');
  ctx.fillStyle = bg;
  ctx.beginPath(); ctx.arc(0, 0, r, 0, TAU); ctx.fill();
  ctx.save();
  ctx.beginPath(); ctx.arc(0, 0, r - 2, 0, TAU); ctx.clip();
  // heaume : dôme acier
  const hg = ctx.createLinearGradient(0, -r, 0, r * 0.4);
  hg.addColorStop(0, '#cfd6dd'); hg.addColorStop(0.55, '#8d97a3'); hg.addColorStop(1, '#4c565f');
  ctx.fillStyle = hg;
  ctx.beginPath();
  ctx.moveTo(-r * 0.82, r * 0.45);
  ctx.quadraticCurveTo(-r * 0.85, -r * 0.75, 0, -r * 0.85);
  ctx.quadraticCurveTo(r * 0.85, -r * 0.75, r * 0.82, r * 0.45);
  ctx.closePath(); ctx.fill();
  // nasal central
  ctx.fillStyle = '#39424b';
  ctx.fillRect(-r * 0.09, -r * 0.55, r * 0.18, r * 0.85);
  // fente oculaire : lueur du regard
  const eyeGlow = 0.65 + Math.sin(G.time * 2.4) * 0.2;
  ctx.fillStyle = `rgba(120,200,255,${eyeGlow})`;
  ctx.fillRect(-r * 0.62, -r * 0.18, r * 1.24, r * 0.14);
  // rivets du heaume
  ctx.fillStyle = HPAL.gold;
  for (const a of [-0.7, 0, 0.7]) {
    ctx.beginPath(); ctx.arc(Math.sin(a) * r * 0.78, r * 0.28 + Math.cos(a) * r * 0.2, 1.6, 0, TAU); ctx.fill();
  }
  // panache / cimier or
  ctx.fillStyle = HPAL.gold;
  ctx.beginPath();
  ctx.moveTo(0, -r * 0.85);
  ctx.quadraticCurveTo(r * 0.25, -r * 1.15, r * 0.12, -r * 0.98);
  ctx.quadraticCurveTo(0, -r * 1.12, -r * 0.12, -r * 0.98);
  ctx.quadraticCurveTo(-r * 0.25, -r * 1.15, 0, -r * 0.85);
  ctx.fill();
  ctx.restore();
  // anneau métallique + gemme de niveau
  ctx.strokeStyle = HPAL.goldLo; ctx.lineWidth = 3;
  ctx.beginPath(); ctx.arc(0, 0, r + 1.5, 0, TAU); ctx.stroke();
  ctx.strokeStyle = HPAL.gold; ctx.lineWidth = 1;
  ctx.beginPath(); ctx.arc(0, 0, r - 1, 0, TAU); ctx.stroke();
  ctx.restore();
}

export function drawProfile() {
  const p = G.player;
  const hpFrac = Math.max(0, Math.min(1, p.hp / p.maxHp));
  const now = G.time || 0;

  // ---- suivi dégâts / soins : traînée + flash ----
  if (G._hudHp === undefined) { G._hudHp = hpFrac; G._hudGhost = hpFrac; G._hudHurt = -9; G._hudHeal = -9; }
  if (hpFrac < G._hudHp - 0.0005) G._hudHurt = now;          // dégâts
  else if (hpFrac > G._hudHp + 0.0005) G._hudHeal = now;     // soins
  // la traînée se résorbe lentement vers la vie réelle
  G._hudGhost += (hpFrac - G._hudGhost) * Math.min(1, 0.045);
  if (hpFrac > G._hudGhost) G._hudGhost = hpFrac;
  G._hudHp = hpFrac;
  const hurtA = Math.max(0, 1 - (now - G._hudHurt) / 0.7);
  const healA = Math.max(0, 1 - (now - G._hudHeal) / 0.9);

  // ---- cadre du panneau ----
  const lowHp = hpFrac <= 0.3;
  metalFrame(PX, PY, PW, PH, 10, { glow: lowHp ? 'rgba(224,64,81,0.5)' : null });
  // gemme de statut en haut à droite du cadre (rouge si PV bas, or sinon)
  gem(PX + PW - 16, PY + 12, 5.5, lowHp ? HPAL.redHi : HPAL.green, 0.4);

  // ---- portrait + niveau ----
  const pcx = PX + 46, pcy = PY + PH / 2 - 4, pr = 32;
  drawPortrait(pcx, pcy, pr);
  // badge niveau sous le portrait
  ctx.fillStyle = 'rgba(0,0,0,0.6)';
  roundRect(pcx - 24, pcy + pr + 3, 48, 15, 7); ctx.fill();
  ctx.strokeStyle = HPAL.goldLo; ctx.lineWidth = 1;
  roundRect(pcx - 24, pcy + pr + 3, 48, 15, 7); ctx.stroke();
  engraved(`NIV ${p.level}`, pcx, pcy + pr + 14, 10.5, HPAL.goldHi, 'center', 'Consolas, monospace');

  // ---- colonne droite : nom, monde/temps, vague/monstres ----
  const bx = pcx + pr + 12; // x de départ du bloc droit
  const bw = PX + PW - 14 - bx;
  const heroName = (slotMeta(activeSlot()) || {}).name || 'HÉROS';
  engraved(heroName.toUpperCase(), bx, PY + 24, 13.5, HPAL.parch, 'left');
  // ligne 1 : monde + temps de partie
  const wdef = curWorld() && curWorld().def;
  const t = Math.floor(G.runTime || 0);
  ctx.font = '10px Georgia, serif'; ctx.textAlign = 'left'; ctx.fillStyle = 'rgba(216,196,154,0.8)';
  ctx.fillText(`${wdef ? wdef.name : 'MONDE'}  ·  ${Math.floor(t / 60)}:${String(t % 60).padStart(2, '0')}`, bx, PY + 38);

  // ---- barre PV (rouge profond) : valeurs centrées sur la jauge ----
  const barX = bx, barW = bw, barY = PY + 56, barH = 20;
  medBar(barX, barY, barW, barH, hpFrac, hurtA > 0 ? G._hudGhost : null,
    lowHp ? '#e0606a' : HPAL.redHi, lowHp ? '#6e1420' : HPAL.red,
    { glow: lowHp && hpFrac > 0.02 ? '#ff5a6a' : null });
  engraved('PV', barX + 7, barY + barH / 2 + 3.5, 9.5, 'rgba(255,235,220,0.9)', 'left', 'Consolas, monospace');
  engraved(`${Math.ceil(p.hp)}/${p.maxHp}`, barX + barW / 2, barY + barH / 2 + 4, 11.5, '#ffe9e9', 'center', 'Consolas, monospace');

  // ---- barre XP (or fin) + XP restant ----
  const xpY = barY + barH + 6;
  medBar(barX, xpY, barW, 8, p.xp / p.xpNext, null, '#f0d488', '#8a6a2f', { glow: '#d4a84b' });
  engraved(`+${Math.max(0, Math.ceil(p.xpNext - p.xp))} XP`, barX + barW - 4, xpY + 7.5, 9.5, '#f0d488', 'right', 'Consolas, monospace');

  // ---- barre d'ultime (couleur de l'ulti choisi) ----
  const uY = xpY + 18;
  const ultSel = G.stats.ultSel || 'nuke';
  const ultInfo = ultSel === 'glace' && G.stats.iceUlt
    ? { name: 'PLUIE DE GLACE', barA: '#b3e5fc', barB: '#0277bd', glow: '#0288d1', ready: '#81d4fa' }
    : ultSel === 'hell' && G.stats.hellUlt
      ? { name: 'TITAN DE FEU', barA: '#ffab91', barB: '#bf360c', glow: '#e64a19', ready: '#ff7043' }
      : { name: 'BOMBE ATOMIQUE', barA: '#ffcc80', barB: '#7a2e0e', glow: '#ff5722', ready: '#ff8a65' };
  const ultReady = p.ultCharge >= 100;
  medBar(barX, uY, barW, 14, p.ultCharge / 100, null, ultInfo.barA, ultInfo.barB,
    { glow: ultReady ? ultInfo.glow : null });
  engraved(`[F] ${ultInfo.name}`, barX + 7, uY + 10.5, 9.5, ultReady ? ultInfo.ready : '#fff3d6', 'left', 'Georgia, serif');
  engraved(`${Math.floor(p.ultCharge)}%`, barX + barW - 7, uY + 10.5, 10.5, '#fff', 'right', 'Consolas, monospace');
  if (ultReady) {
    ctx.globalAlpha = 0.65 + Math.sin(G.time * 6) * 0.35;
    engraved('PRÊT !', barX + barW - 56, uY - 3, 10.5, ultInfo.ready, 'right', 'Consolas, monospace');
    ctx.globalAlpha = 1;
  }

  // ---- bouclier du module énergétique : visible uniquement quand le bouclier est actif ----
  const sMax = modShieldMax();
  if (sMax > 0 && (p.modShield || 0) > 0) {
    const mY = uY + 17, mH = 7;
    const mFrac = Math.max(0, Math.min(1, p.modShield / sMax));
    medBar(barX, mY, barW, mH, mFrac, null, '#5fd4ff', '#0a4a66', { glow: '#4fc3f7' });
    engraved('🛡 MODULE', barX + 6, mY + mH / 2 + 2.5, 8.5, 'rgba(216,196,154,0.85)', 'left', 'Georgia, serif');
    engraved(`${Math.ceil(p.modShield)}/${sMax}`, barX + barW - 6, mY + mH / 2 + 2.5, 8.5, '#9be7ff', 'right', 'Consolas, monospace');
  }

  // ---- flèches de feedback PV (bordure qui s'embrase) ----
  if (hurtA > 0) {
    ctx.save();
    ctx.globalAlpha = hurtA * 0.55;
    ctx.strokeStyle = '#ff3b4e'; ctx.lineWidth = 3;
    roundRect(PX + 1.5, PY + 1.5, PW - 3, PH - 3, 9); ctx.stroke();
    ctx.restore();
  } else if (healA > 0) {
    ctx.save();
    ctx.globalAlpha = healA * 0.4;
    ctx.strokeStyle = HPAL.greenHi; ctx.lineWidth = 2.5;
    roundRect(PX + 1.5, PY + 1.5, PW - 3, PH - 3, 9); ctx.stroke();
    ctx.restore();
  }

  // ---- badge poison sous le panneau (statut joueur) ----
  if (p.poisonT > 0) {
    engraved(`☠ POISON ${p.poisonT.toFixed(1)}s`, PX + 6, PY + PH + 14, 10.5, '#a4d94e', 'left', 'Consolas, monospace');
  }
}
