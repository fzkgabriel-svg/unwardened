@echo off
title Les Terres Oubliees
start "" "%~dp0index.html"
